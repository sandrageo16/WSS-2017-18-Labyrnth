#ifndef _TESTSENDER_HPP
#define _TESTSENDER_HPP

#include <iostream>
#include <boost/array.hpp>
#include <boost/asio.hpp>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <mraa.hpp>
#include <fstream>
#include "OLEDDisplay.h"
#include <vector>
#include <stdio.h>
using boost :: asio :: ip :: address ;
using boost :: asio :: ip :: udp ;
using std::to_string;
using boost::asio::buffer;
using namespace GFX;
using namespace std;

class testSender
{
	private:
		udp::socket &socket;
		
	public :
	testSender(udp::socket &socket) : socket(socket) {}
		
	void sendInts(int select_variable, int a, int b);
	void sendString(int select_variable, std::string str);
};

#endif
