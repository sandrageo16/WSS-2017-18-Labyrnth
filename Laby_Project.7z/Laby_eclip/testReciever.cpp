#include <iostream>
#include <boost/array.hpp>
#include <boost/asio.hpp>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <mraa.hpp>
#include <fstream>
#include "OLEDDisplay.h"
#include <vector>
#include <stdio.h>
#include "testReciever.hpp"
#include "Marble.hpp"
using boost :: asio :: ip :: address ;
using boost :: asio :: ip :: udp ;
using std::to_string;
using boost::asio::buffer;
using namespace GFX;
using namespace std;

 
 std::vector<std::string> split(std::string str, char delimiter) {
  std::vector<std::string> aux;
  std::stringstream ss(str); // Turn the string into a stream.
  std::string tok;
  
  while(getline(ss, tok, delimiter)) {
    aux.push_back(tok);
  }
  
  return aux;
}

void testReciever::recieve() 
{
	udp::endpoint sender;
	boost::array<char, 200> buf;	
	boost::system::error_code err;
	
	while (1)
	{
		size_t len = socket.receive_from(buffer(buf), sender, 0, err);
		if (err)
			break;
		
		std::string message(buf.c_array(), len); 
		std::cout<< "Got:" << message << std::endl;		
		std::vector<std::string> parsed = split(message, ':');
		std:: string LABY = parsed[0];
		if (LABY == "LABY"){                                //Check for the first string, if not LABY discard all
			piNumber= std::stoi (parsed[1]);
			
			//If the message from first Pi is recieved
			if (piNumber = 1){
				select_variable = std::stoi (parsed[2]);
				if (select_variable == Parameters){          //temperature and rand
					 P1 = std::stoi(parsed[3]);
					 P2 = std::stoi(parsed[4]);
					master.masterSelect(piNumber,P1,P2);
				}
				if (select_variable == XYPos){               //coordinates
					xPos1 = std::stoi(parsed[3]);
					yPos1 = std::stoi(parsed[4]);
					
				}
				if (select_variable == winnerStat){
					std:: string winnerStatus = parsed[3];    //winner
				}
				if (select_variable == masterStat){
					masterPiNum = std::stoi(parsed[3]);// if I am the master
					masterReady = std::stoi(parsed[4]);
					if(masterPiNum == myPiNum){
						IamMaster = 1;
					}
				}
					
			}
			//If the message from second Pi is recieved
			if (piNumber = 2){
				select_variable = std::stoi (parsed[2]);
				if (select_variable == Parameters){
					P1 = std::stoi(parsed[3]);
					P2 = std::stoi(parsed[4]);
					master.masterSelect(piNumber,P1,P2);
				}
				if (select_variable == XYPos){
					xPos2 = std::stoi(parsed[3]);
					yPos2 = std::stoi(parsed[4]);
				}
				if (select_variable == winnerStat){
					std:: string status = parsed[3];
				}
				if (select_variable == masterStat){
					masterPiNum = std::stoi(parsed[3]);
					masterReady = std::stoi(parsed[4]);
					if(masterPiNum == myPiNum){
						IamMaster = 1;
					}
				}
					
			}
			//If the message from third Pi is recieved
			if (piNumber = 3){
				select_variable = std::stoi (parsed[2]);
				if (select_variable == Parameters){
					P1 = std::stoi(parsed[3]);
					P2 = std::stoi(parsed[4]);
					master.masterSelect(piNumber,P1,P2);
				}
				if (select_variable == XYPos){
					xPos3 = std::stoi(parsed[3]);
					yPos3 = std::stoi(parsed[4]);
				}
				if (select_variable == winnerStat){
					std:: string status = parsed[3];
				}
				if (select_variable == masterStat){
					masterPiNum = std::stoi(parsed[3]);
					masterReady = std::stoi(parsed[4]);
					if(masterPiNum == myPiNum){
						IamMaster = 1;
					}
				}
					
			}
			
		}
	}			

}
		

