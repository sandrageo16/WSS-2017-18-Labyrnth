#include <iostream>
#include <boost/array.hpp>
#include <boost/asio.hpp>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fstream>
#include <vector>
#include <stdio.h>
#include "Master.hpp"



/*Select master based on temperature and random number*/
 void Master :: masterSelect(int piNumber, int P1, int P2 ){   
	if((piNumber==1) && (flagPi1 == 0) )
	{	 
		P01= P1+P2;
		flagPi1 = 1;
	}
		
	if((piNumber==2) && (flagPi2 == 0) )
	{	 
		P02= P1+P2; 
		flagPi2 = 1;			
	}
		
	if((piNumber==3) && (flagPi3 == 0) )
	{	 
		P03= P1+P2; 
		flagPi3 = 1;
	}
	if (flagPi1 && flagPi2 && flagPi3)
	{
		masterReadySend =1;
		
		if(P01>P02 && P01>P03)
		{
			sender.sendInts(sendmasterStat,1,masterReadySend);
		}
		
		if(P02>P01 && P02>P03)
		{
			sender.sendInts(sendmasterStat,2,masterReadySend);
		}

		if(P03>P01 && P03>P02)
		{
		  sender.sendInts(sendmasterStat,3,masterReadySend);
		}
		  //Master Pi has been set
	}
 }
 
 
/* If there is a winner Send the information to other Pis*/
void Master :: displayWinner(int xPos1, int yPos1, int xPos2, int yPos2, int xPos3, int yPos3) 
{
	

		if (xPos1 >= 60 && xPos1 <= 70 && yPos1 >= 60 && yPos1 <= 70 ) 
		{
			sender.sendString(sendwinnerStat,"Player1Wins");		}
		if (xPos2 >= 60 && xPos2 <= 70 && yPos2 >= 60 && yPos2 <= 70 ) 
		{
			sender.sendString(sendwinnerStat,"Player2Wins");
		}
		if (xPos3 >= 60 && xPos3 <= 70 && yPos3 >= 60 && yPos3 <= 70)  
		{
			sender.sendString(sendwinnerStat,"Player3Wins");	

		}

}

