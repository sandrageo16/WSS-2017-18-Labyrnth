#include <iostream>
#include <boost/array.hpp>
#include <boost/asio.hpp>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <mraa.hpp>
#include <fstream>
#include "OLEDDisplay.h"
#include <vector>
#include <stdio.h>
#include "testSender.hpp"
#include "Marble.hpp"
using boost :: asio :: ip :: address ;
using boost :: asio :: ip :: udp ;
using std::to_string;
using boost::asio::buffer;
using namespace GFX;
using namespace std;


//Send parameters and coordinates and master ready status
void testSender::sendInts(int select_variable, int x, int y)

{
	udp::endpoint target(address::from_string("10.126.135.255"),7788);	
	boost::system::error_code err;	
	std::string str = std::string("LABY:") + std::to_string(myPiNum) + ":"+std::to_string(select_variable) + ":"+ std::to_string((long long)x ) + ":" + std::to_string((long long) y);
	socket.send_to(buffer(str), target, 0, err);
	std::cout << "Position sent" << std::endl;
		
}

//Send winner status
void testSender::sendString(int select_variable, std::string winnerStatus)

{
	udp::endpoint target(address::from_string("10.126.135.255"),7788);	
	boost::system::error_code err;	
	std::string str = std::string("LABY:") + std::to_string(myPiNum) + ":"+std::to_string(select_variable) + ":"+ winnerStatus;
	socket.send_to(buffer(str), target, 0, err);
	std::cout << "Position sent" << std::endl;
		
}





